<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css')?>" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css">
    <script src="<?php echo base_url('assets/jquery/jquery-2.1.4.min.js')?>"></script>
<script src="<?php echo base_url('assets/bootstrap/js/bootstrap.min.js')?>"></script>
</head>
<body>

<div class="container">
	<div class="row">
		<div class="col-md-12 text-center">
			<h2>Add User</h2>
			
		</div>
		<div class="col-md-5 col-md-offset-6 text-center">
			<a class = "btn btn-primary" href="<?php echo base_url()."patient"?>">Back</a>
</div>
	</div>
	
	<div class="row">
		
		
        <div class="col-md-12" style="margin:10px 0px ">
        <?php 
				echo validation_errors(); 
				
				if($this->session->flashdata('successMsg'))
				{
					echo '<div class="col-md-6 col-md-offset-3"><div class="alert alert-success">';
					echo $this->session->flashdata('successMsg');
					echo '</div></div>';
				}
				
				if(isset($errorMsg))
				{
					echo '<div class="col-md-6 col-md-offset-3"><div class="alert alert-danger">';
					echo $errorMsg;
					echo '</div></div>';
					unset($errorMsg);
				}
			?>
			
			<form action="<?php echo base_url()."patient/addPatient"?>" method="post">
				<div class="form-group custom-bottom-margin">
					<label class="control-label col-sm-4 text-right" for="name">Name</label>
					<div class="col-sm-5">
					  <input type="text" name="name" class="form-control" value="<?php echo set_value('name'); ?>" placeholder="Enter First name" id="fname">
					</div>
				</div>
				<div class="form-group custom-bottom-margin">
					<label class="control-label col-sm-4 text-right" for="age">Age</label>
					<div class="col-sm-5">
					  <input type="text" name="age" class="form-control" value="<?php echo set_value('age'); ?>" placeholder="Enter Last name" id="lname">
					</div>
                </div>
                <div class="form-group custom-bottom-margin">
					<label class="control-label col-sm-4 text-right" for="gender">Gender</label>
					<div class="col-sm-5">
					  <input type="text" name="gender" class="form-control" value="<?php echo set_value('gender'); ?>" placeholder="Enter Last name" id="lname">
					</div>
				</div>
				<div class="form-group custom-bottom-margin">
					<label class="control-label col-sm-4 text-right" for="email">Email</label>
					<div class="col-sm-5">
					  <input type="email" name="email" class="form-control" value="<?php echo set_value('email');?>" placeholder="Enter email" id="email">
					</div>
				</div>			
				<div class="form-group custom-bottom-margin">
					<label class="control-label col-sm-4 text-right" for="mobile">Phone</label>
					<div class="col-sm-5">
					  <input type="text" name="mobile" class="form-control" value="<?php echo set_value('mobile');?>" placeholder="Enter phone" id="phone">
					</div>
				</div>
				
				<div class="form-group custom-bottom-margin">
					<label class="control-label col-sm-4 text-right"></label>
					<div class="col-sm-5">
					  <button class="btn btn-primary" type="submit"> Submit</button>
					</div>
				</div>
				
				
			</form>
		</div>
	</div>
</div>

    
</body>
</html>

