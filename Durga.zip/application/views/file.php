
<div class="content-wrapper">
    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-md-12">
                <div class="box box-primary">
                    <div class="box-header with-border">
                        <h3 class="box-title titlefix"><?php echo $this->lang->line('pathology') . " " . $this->lang->line('test'); ?></h3>
                        <div class="box-tools pull-right">
                        <button id="myBtn">Open Modal</button>

<!-- The Modal -->
<div id="myModal" class="modal">

  <!-- Modal content -->
  <div class="modal-content">
    <div class="modal-header">
      <span class="close">&times;</span>
      <h2>Modal Header</h2>
    </div>
    <div class="modal-body">
      <p>Some text in the Modal Body</p>
      <p>Some other text...</p>
    </div>
    <div class="modal-footer">
      <h3>Modal Footer</h3>
    </div>
  </div>

</div>
                 </div>
                       
                    </div><!-- /.box-header -->
                    <div class="box-body">
                        <div class="download_label"><?php echo $this->lang->line('pathology') . " " . $this->lang->line('test'); ?></div>
                        <table class="table table-striped table-bordered table-hover example" cellspacing="0" width="100%">
                            <thead>
                                <tr>
                                    <th><?php echo $this->lang->line('patient') . " " . $this->lang->line('name'); ?></th>
                                    <th><?php echo $this->lang->line('patient') . " " . $this->lang->line('id'); ?></th>
                                    <th><?php echo $this->lang->line('guardian') . " " . $this->lang->line('name'); ?></th>
                                    <th><?php echo $this->lang->line('age'); ?></th>
                                    <th><?php echo $this->lang->line('email'); ?></th>
                                    <th><?php echo $this->lang->line('phone') . " " . $this->lang->line('number'); ?></th>
                                    <th><?php echo $this->lang->line('action'); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                if (empty($patients)) {
                                    ?>
                                            
                                    <?php
                                } else {
                                    $count = 1;
                                    foreach ($patients as $student) {
                                        ?>
                                        <tr class="">
                                            <td>
                                                <a href="#" data-toggle="tooltip" title="<?php echo $this->lang->line('show'); ?>"
                                                   onclick="viewDetail('<?php echo $student['id'] ?>')"><?php echo $student['patient_name']; ?></a> 
                                                <div class="rowoptionview">
                                                    <?php if ($this->rbac->hasPrivilege('add_patho_patient_test_report', 'can_add')) { ?>
                                                        <a href="#" onclick="addTestReport('<?php echo $student['id'] ?>')" class="btn btn-default btn-xs"  data-toggle="tooltip" title="<?php echo $this->lang->line('add_test_report'); ?>">
                                                            <i class="fa fa-plus-square" aria-hidden="true"></i>
                                                        </a> 
                                                    <?php } ?>
                                                    <?php if ($this->rbac->hasPrivilege('pathology test', 'can_view')) { ?>   
                                                        <a href="<?php echo base_url(); ?>admin/bbs_controller/view" class="btn btn-primary btn-sm"><i class="fa fa-reorder"></i> <?php echo $this->lang->line('assign') . " " . $this->lang->line('test'); ?></a> 
                                                    <?php } ?>
                                                    <?php if ($this->rbac->hasPrivilege('pathology test', 'can_view')) { ?>  
                                                        <a href="#" data-toggle="tooltip" 
                                                           onclick="viewDetail('<?php echo $student['id'] ?>')"
                                                           class="btn btn-default btn-xs" 
                                                           title="<?php echo $this->lang->line('show'); ?>" >
                                                            <i class="fa fa-reorder"></i>
                                                        </a> 
                                                    <?php } ?>
                                                </div>  
                                            </td>
                                            <td><?php echo $student['patient_unique_id']; ?></td>
                                            <td><?php echo $student['guardian_name']; ?></td>
                                            <td><?php echo $student['age']; ?></td>
                                            <td><?php echo $student['email']; ?></td>
                                            <td><?php echo $student['mobileno']; ?></td>
                                            <td><?php echo $student['']; ?></td>
                                        </tr>
                                        <?php
                                        $count++;
                                    }
                                }
                                ?>
                            </tbody>

                        </table>
                    </div>
                </div>                                                    
            </div>                                                                                        
        </div>  
    </section>
</div>


<div class="modal" id="viewModalbbs" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content modal-media-content">
            <div class="modal-header modal-media-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="box-title"><?php echo $this->lang->line('patient') . " " . $this->lang->line('information'); ?></h4> 
            </div>
            <form id="view" accept-charset="utf-8" method="get" class="">    
                <div class="modal-body pt0 pb0">
                    <div class="">


                        <div class="table-responsive">
                            <table class="table mb0 tablelr0space table-striped table-bordered examples">
                                <tr>
                                    <th width="15%"><?php echo $this->lang->line('patient') . " " . $this->lang->line('name'); ?></th>
                                    <td width="35%"><span id='patient_names'></span></td>
                                </tr>
                            </table>
                        </div>
                    </div><!--./row--> 
                </div>    
            </form>    
        </div>
    </div>    
</div>

<div class="modal fade" id="myModal"  role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content modal-media-content">
            <div class="modal-header modal-media-header">
                <button type="button" class="close pt4" data-dismiss="modal">&times;</button>
                <div class="row">
                    <div class="col-sm-6 col-xs-8">
                        <div class="form-group15">
                            <div>
                                <select onchange="get_PatientDetails(this.value)" style="width:100%" class="form-control select2"  name='patient_id' id="addpatient_id" >
                                    <option value=""><?php echo $this->lang->line('select') . " " . $this->lang->line('patient') ?></option>
                                    <?php foreach ($patients as $dkey => $dvalue) {
                                        ?>
                                        <option value="<?php echo $dvalue["id"]; ?>" <?php
                                        if ((isset($patient_select)) && ($patient_select == $dvalue["id"])) {
                                            echo "selected";
                                        }
                                        ?>><?php echo $dvalue["patient_name"] . " (" . $dvalue["patient_unique_id"] . ')' ?></option>   
                                            <?php } ?>
                                </select>
                            </div>
                            <span class="text-danger"><?php echo form_error('refference'); ?></span>
                        </div>
                    </div><!--./col-sm-8-->
                    <div class="col-sm-4 col-xs-3">
                        <div class="form-group15">
                            <?php if ($this->rbac->hasPrivilege('pathology test', 'can_add')) { ?>
                                <a data-toggle="modal" id="add" onclick="holdModal('myModalpa')" class="modalbtnpatient"><i class="fa fa-plus"></i>  <span><?php echo $this->lang->line('new') . " " . $this->lang->line('patient') ?></span></a> 
                            <?php } ?> 

                        </div>
                    </div><!--./col-sm-4--> 
                </div><!-- ./row -->  
            </div>

            <div class="modal-body pt0 pb0">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12">
                        <form id="formbatch" accept-charset="utf-8" enctype="multipart/form-data" method="post"  action="">
                            <div class="row row-eq">

                                <div class="col-lg-6 col-md-6 col-sm-6">
                                    <div id="ajax_load"></div>
                                    <div class="row ptt10" id="patientDetails" style="display:none">
                                        <input type="hidden" name="pathology_id" id="patho_id" >
                                        <input type="hidden" name="patient_id" id="patho_patientid" >
                                        <div class="col-md-9 col-sm-9 col-xs-9">

                                            <ul class="singlelist">
                                                <li class="singlelist24bold">
                                                    <span id="listname"></span></li>
                                                <li>
                                                    <i class="fas fa-user-secret" data-toggle="tooltip" data-placement="top" title="Guardian"></i>
                                                    <span id="guardian"></span>
                                                </li>
                                            </ul>   
                                            <ul class="multilinelist">   
                                                <li>
                                                    <i class="fas fa-venus-mars" data-toggle="tooltip" data-placement="top" title="Gender"></i>
                                                    <span id="genders" ></span>
                                                </li>
                                                <li>
                                                    <i class="fas fa-tint" data-toggle="tooltip" data-placement="top" title="Blood Group"></i>
                                                    <span id="blood_group"></span>
                                                </li>
                                                <li>
                                                    <i class="fas fa-ring" data-toggle="tooltip" data-placement="top" title="Marital Status"></i>
                                                    <span id="marital_status"></span>
                                                </li> 
                                            </ul>  
                                            <ul class="singlelist">  
                                                <li>
                                                    <i class="fas fa-hourglass-half" data-toggle="tooltip" data-placement="top" title="Age"></i>
                                                    <span id="age"></span>
                                                </li>    

                                                <li>
                                                    <i class="fa fa-phone-square" data-toggle="tooltip" data-placement="top" title="Phone"></i> 
                                                    <span id="listnumber"></span>
                                                </li>
                                                <li>
                                                    <i class="fa fa-envelope" data-toggle="tooltip" data-placement="top" title="Email"></i>
                                                    <span id="email"></span>
                                                </li>
                                                <li>
                                                    <i class="fas fa-street-view" data-toggle="tooltip" data-placement="top" title="Address"></i>
                                                    <span id="address" ></span>
                                                </li>

                                                <li>
                                                    <b><?php echo $this->lang->line('any_known_allergies') ?> </b> 
                                                    <span id="allergies" ></span>
                                                </li>
                                                <li>
                                                    <b><?php echo $this->lang->line('remarks') ?> </b> 
                                                    <span id="note"></span>
                                                </li>    
                                            </ul>                               
                                        </div><!-- ./col-md-9 -->
                                        <div class="col-md-3 col-sm-3 col-xs-3"> 
                                            <div class="pull-right">  
                                              <!--<b><?php echo $this->lang->line('patient') . " " . $this->lang->line('photo') ?> </b>-->
                                                        <!--<span id="image"></span>-->
                                                <?php
                                                $file = "uploads/patient_images/no_image.png";
                                                ?>        
                                                <img class="modal-profile-user-img img-responsive" src="<?php echo base_url() . $file ?>" id="image" alt="User profile picture">
                                            </div>           
                                        </div><!-- ./col-md-3 --> 
                                    </div>
                                </div><!--./col-md-8--> 


                                <div class="col-lg-6 col-md-6 col-sm-6 col-eq ptt10">
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <div class="form-group">
                                                <label><?php echo $this->lang->line('reporting') . " " . $this->lang->line('date'); ?></label><small class="req"> *</small>
                                                <input type="text" id="report_date" name="reporting_date" class="form-control date">
                                                <span class="text-danger"><?php echo form_error('reporting_date'); ?></span>
                                            </div>
                                        </div>



                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label for="description"><?php echo $this->lang->line('description'); ?></label> 

                                                <textarea name="description" class="form-control" ></textarea>
                                                <span class="text-danger"><?php echo form_error('description'); ?>
                                                </span>
                                            </div> 
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label><?php echo $this->lang->line('test') . " " . $this->lang->line('report'); ?></label>
                                <input type="file" name="pathology_report" class="filestyle form-control" data-height="40" />
                                                <span class="text-danger"><?php echo form_error('pathology_report'); ?></span>
                                            </div>
                                        </div> 

                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label for="exampleInputFile">
                                                    <?php echo $this->lang->line('refferal') . " " . $this->lang->line('doctor'); ?></label>
                                                <div>
                                                    <select class="form-control select2" style="width:100%" name='consultant_doctor' id="consultant_doctor">
                                                        <option value="<?php echo set_value('consultant_doctor'); ?>"><?php echo $this->lang->line('select') ?></option>
                                                        <?php foreach ($doctors as $dkey => $dvalue) {
                                                            ?>
                                                            <option value="<?php echo $dvalue["id"]; ?>"><?php echo $dvalue["name"] . " " . $dvalue["surname"] ?></option>   
                                                        <?php } ?>
                                                    </select>
                                                </div>
                                                <span class="text-danger"><?php echo form_error('consultant_doctor'); ?></span>
                                            </div>
                                        </div> 

                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label><?php echo $this->lang->line('charge') . " " . $this->lang->line('category'); ?></label>

                                                <input type="text" id="charge_category_html" class="form-control" readonly>

                                            </div>
                                        </div>

                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label><?php echo $this->lang->line('code'); ?></label>

                                                <input type="text" id="code_html" class="form-control" readonly>
                                            </div>
                                        </div>

                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label><?php echo $this->lang->line('standard') . " " . $this->lang->line('charge') . ' (' . $currency_symbol . ')'; ?></label>

                                                <input type="text" id="charge_html" class="form-control" readonly>
                                            </div>
                                        </div>

                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label><?php echo $this->lang->line('applied') . " " . $this->lang->line('charge') . ' (' . $currency_symbol . ')'; ?>
                                                    <small class="req"> *</small>
                                                </label>
                                                <input type="text" name="apply_charge" id="apply_charge" class="form-control" >
                                            </div>
                                        </div> 

                                    </div><!--./row-->    
                                </div><!--./col-md-4-->
                            </div><!--./row--> 

                            <div class="row">            
                                <div class="box-footer">
                                    <div class="pull-right mrminus8">
                                        <button type="submit" id="formbatchbtn" data-loading-text="<?php echo $this->lang->line('processing') ?>" class="btn btn-info pull-right"><?php echo $this->lang->line('save'); ?></button>
                                    </div>
                                    <div class="pull-right" style="margin-right:10px;">
                                        <button type="button"  data-loading-text="<?php echo $this->lang->line('processing') ?>" class="btn btn-info pull-right printsavebtn"><?php echo $this->lang->line('save') . " & " . $this->lang->line('print'); ?></button>
                                    </div>
                                </div>
                            </div><!--./row-->  
                        </form>                       
                    </div><!--./col-md-12-->       
                </div><!--./row--> 
            </div>
        </div>
    </div>    
</div>


<script type="text/javascript">

    function viewDetail(id) {
        $.ajax({
            url: '<?php echo base_url(); ?>admin/bbs_controller/getPatientDetails',
            type: "POST",
            data: {patients_id: id},
            dataType: 'json',
            success: function (data) {
                $("#patient_names").html(data.patient_name);
                holdModal('viewModalbbs');
            },
        });
    }

    function addTestReport(id) {
        $.ajax({
            url: '<?php echo base_url(); ?>admin/bbs_controller/getPatients',
            type: "POST",
            data: {patients_id: id},
            dataType: 'json',
            success: function (data) {
                $("#patho_id").val(id);
                $("#charge_category_html").val(data.charge_category);
                $("#code_html").val(data.code);
                $("#charge_html").val(data.standard_charge);
                $("#apply_charge").val(data.standard_charge);
                holdModal('myModal');
            },
        })
    } 


var modal = document.getElementById("myModal");
var btn = document.getElementById("myBtn");
var span = document.getElementsByClassName("close")[0];
btn.onclick = function() {
  modal.style.display = "block";
}
span.onclick = function() {
  modal.style.display = "none";
}

window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
}
</script>

****************************************************controller**************
<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Bbs_controller extends Admin_Controller {
    public function __construct() {
        parent::__construct();
        // $this->load->model('bbs_model');
    }

    function index(){
        // print_r('coming');
        // echo 'coming';

        if (!$this->rbac->hasPrivilege('pathology test', 'can_view')) {
            access_denied();
        }

        $data['patients'] = $this->pathology_model->getPatients();
       
        $this->load->view('layout/header');
        $this->load->view('admin/bbs/bbs.php',$data);
        $this->load->view('layout/footer');
    }

    function view(){
        // $getPatientID = $id;
        // $details = $this->pathology_model->getDetails();
        // $data['records'] = $this->pathology_model->getPatientDetailsByID($getPatientID);

        $id = $this->input->post("patients_id");
        $result['records'] = $this->pathology_model->getPatientDetailsByID($id);
        echo json_encode($result);
        $this->load->view('layout/header');
        $this->load->view('admin/bbs/bbs_view.php');
        $this->load->view('layout/footer');
    }
    function getPatientDetails(){
        if (!$this->rbac->hasPrivilege('pathology test', 'can_view')) {
            access_denied();
        }
        $id = $this->input->post("patients_id");
        $result = $this->pathology_model->getPatientsDetails($id);
        echo json_encode($result);
    }
    
    public function getPatients() {
        if (!$this->rbac->hasPrivilege('pathology test', 'can_view')) {
            access_denied();
        }

        $id = $this->input->post('patients_id');
        $result = $this->pathology_model->assignTest($id);
        echo json_encode($result);
    }
}