<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css')?>" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css">
    <script src="<?php echo base_url('assets/jquery/jquery-2.1.4.min.js')?>"></script>
<script src="<?php echo base_url('assets/bootstrap/js/bootstrap.min.js')?>"></script>
</head>
<body>
	<div class="container">
	<div class="row">
		<div class="col-md-12 text-center" style="margin:10px 0px ">
			<h2>Patient Details</h2>
		</div>
		
		<div class="col-md-12" style="margin:10px 0px ">
			<a class = "btn btn-primary btn-sm" href="<?php echo base_url().""?>">Add Patient</a>
		</div>
		<div class="col-md-12">
		
	<?php				
		if(!empty($getPatients))
		{
			echo '<table class="table">';
            echo '<tr>';
            echo '<th>Id</th>';
			echo '<th>Name</th>';
            echo '<th>Age</th>';
            echo '<th>Gender</th>';
            echo '<th>Email</th>';
            echo '<th>Phone</th>';
			echo '<th>Action</th>';
			echo '</tr>';
			
			foreach($getPatients as $user)
			{
                    echo '<tr>';
                    echo "<td>".$user['patient_id']."</td>";
					echo "<td>".$user['name']."</td>";
                    echo "<td>".$user['age']."</td>";
                    echo "<td>".$user['gender']."</td>";
                    echo "<td>".$user['email']."</td>";
                    echo "<td>".$user['mobile']."</td>";
					echo '<td><a href="'.base_url().'patient/view/'.$user["patient_id"].'" class="btn btn-info btn-sm">Assign Test</a></td>';
					echo '</tr>';
			}
			
			echo '</table>';
		}
	?>
	</div>
	</div>
	</div>

        
</body>
</html>
	

