<?php
$ids = 100000;
$i = 0; 
$n = 0; 
$l = "BBS.A"; 

while ($i <= $ids) { 
    $id = $l . sprintf("%05d", $n); 
    echo $id . "<br>"; 

    if ($n == 99999) {
        $n = 0;
        $l++;
    }

    $i++; $n++; 
}
?>