<!DOCTYPE html>
<html lang="en">
 <head>
  <title>Patient-Test Details</title>
  <script src="<?php echo base_url('assets/jquery/jquery-2.1.4.min.js')?>"></script>
    <script src="<?php echo base_url('assets/bootstrap/js/bootstrap.min.js')?>"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
 </head>
 <body>
   <div style="width:90%;margin:50px;">
    <h4>Patient-Test Details</h4>

    <table class="table table-striped table-bordered">
     <tr>
      <td><strong>Invoice No</strong></td>
      <td><strong>Patient Id</strong></td>
     <td><strong>Patient</strong></td>
     <td><strong>Gender</strong></td>
     <td><strong>Age</strong></td>
     <td><strong>Test ID</strong></td>
     <td><strong>Test Name</strong></td>
     <td><strong>Test Code</strong></td>
     <td><strong>Description</strong></td>
     <td><strong>Date</strong></td>
     <td><strong>Doctor</strong></td>
     <td><strong>Std.Charge</strong></td>
     <td><strong>App.Charge</strong></td>
     <td><strong>GST</strong></td>
     <td><strong>Grand Total</strong></td>
    </tr> 

     <?php foreach($alldb as $patients){?>
     <tr>
    <td align="center"><?=$patients->invoice_no;?></td>
    <td align="center"><?=$patients->patient_id;?></td>
     <td align="center"><?=$patients->name;?></td>
     <td align="center"><?=$patients->gender;?></td>
     <td align="center"><?=$patients->age;?></td>
     <td align="center"><?=$patients->test_id;?></td>
     <td align="center"><?=$patients->test_name;?></td>
     <td align="center"><?=$patients->code;?></td>
     <td align="center"><?=$patients->description;?></td>
     <td align="center"><?=$patients->report_date;?></td>
     <td align="center"><?=$patients->doctor;?></td>
     <td align="center"><?=$patients->standard_charge;?></td>
     <td align="center"><?=$patients->applied_charge;?></td>
     <td align="center"><?=$patients->gst;?></td>
     <td align="center"><?=$patients->total_amount;?></td>
    </tr>     
        <?php }?>  
    </table>
   </div> 
 </body>
</html>