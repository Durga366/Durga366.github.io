<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Patient List</title>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
 <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>

</head>
<body>
  
<div class="container">
  <br />
  <br />
  <h3 align="center">Patient Test List</h3>
  <br />
  <?=form_open('patient/search');?>
<?php $search = array('name'=>'search','id'=>'search','value'=>"");?>
<?=form_input($search);?><input type=submit value='Search Here' /></p>
<?=form_close();?>
  <?php
  if(isset($patient_data)) {
  ?>
  <div class="table-responsive">
   <table class="table table-striped table-bordered">
    <tr>
     <th>#</th>
     <th>Invoice</th>
     <th>Patient ID</th>
     <th>Name</th>
     <th>Email</th>
     <th>Age</th>
     <th>Phone</th>
     <th>Test ID</th>
     <th>Name</th>
     <th>Code</th>
     <th>Std.Charge</th>
     <th>Doctor</th>
     <th>Description</th>
     <th>Report Date</th>
     <th>App Charge</th>
     <th>GST</th>
     <th>Grand Total</th>
     <th>View</th>
    </tr>
   <?php
   foreach($patient_data->result() as $row)
   {
    echo '
    <tr>
     <td align="center">'.$row->id.'</td>
     <td align="center">'.$row->invoice_no.'</td>
     <td align="center">'.$row->patient_id.'</td>
     <td align="center">'.$row->name.'</td>
     <td align="center">'.$row->email.'</td>
     <td align="center">'.$row->age.'</td>
     <td align="center">'.$row->mobile.'</td>
     <td align="center">'.$row->test_id.'</td>
     <td align="center">'.$row->test_name.'</td>
     <td align="center">'.$row->code.'</td>
     <td align="center">'.$row->standard_charge.'</td>
     <td align="center">'.$row->doctor.'</td>
     <td align="center">'.$row->description.'</td>
     <td align="center">'.$row->report_date.'</td>
     <td align="center">'.$row->applied_charge.'</td>
     <td align="center">'.$row->gst.'</td>
     <td align="center">'.$row->total_amount.'</td>
     <td align="center"><a href="'.base_url().'patient/pdfdetails/'.$row->id.'">Print</a></td>
    </tr>
    ';
   }
   ?>
   
   </table>
  </div>

  <?php } ?>
  <a class = "btn btn-primary btn-sm pull-right" href="<?php echo base_url()."patient"?>">Back</a>
 </div>


</body>
</html> 


