<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script src="<?php echo base_url('assets/jquery/jquery-2.1.4.min.js')?>"></script>
    <script src="<?php echo base_url('assets/bootstrap/js/bootstrap.min.js')?>"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
    <script>
      $(document).ready(function() {
    $('#logic').table_data( {
        dom: 'Bfrtip',
        buttons: [
            'print'
        ]
    } );
} );
    </script>
    <!-- <script>
    $(document).ready(function(){
 	$('#logic tbody').on('keyup change',function(){
 	calc();
 	});

 	$('#tax').on('keyup change',function(){
calc_total();
 	});
 });

 function calc()
 {
 	$('#logic tbody ').each(function(i, element) {
 		var html = $(this).html();
 		if(html!='')
 		{
 			var qty = $(this).find('.std_charge').val();
 			var price = $(this).find('.applied_charge').val();
 			$(this).find('.sum').val(+qty + +price);
			
 			calc_total();
 		}
     });
}

 function calc_total()
 {
 	total=0;
 	$('.sum').each(function() {
         total += parseInt($(this).val());
   });
 	tax_sum=total/100*$('#tax').val();
 	$('#total_amount').val((tax_sum+total).toFixed(2));
}
</script> -->
</head>
<body style="background-color: #f4fffc;">

<div class="container">
	<div class="row"><br/><br/>
    <?php
    $patient_id  = $records['patient_id'] ? $records['patient_id'] : '';
    $name        = $records['name'] ? $records['name'] : '';
    $email       = $records['email'] ? $records['email'] : '';
    $gender      = $records['gender'] ? $records['gender'] : '';
    $mobile      = $records['mobile'] ? $records['mobile'] : '';
    $age         = $records['age'] ? $records['age'] : '';
    ?>
    
    <div class="col-sm-3 bg-info">
     <div class="row">
     <button type="button" class="btn btn-primary btn-sm" id="btn">Patient Info</button> <br/><br />   
        <p align="center"><strong>Id:      </strong><?php print $patient_id?></p>
        <p align="center"><strong>Name:    </strong><?php print $name?></p>
        <p align="center"><strong>Email:   </strong><?php print $email?></p>
        <p align="center"><strong>Gender:  </strong><?php print $gender?></p>
        <p align="center"><strong>Phone:   </strong><?php print $mobile?></p>
        <p align="center"><strong>Age:     </strong><?php print $age?></p><br />  
    </div>
    </div>
    <!-- </div> -->

    <div class="col-sm-9 bg-success">
    <div class="row">
<!-- <button type="text" class="btn btn-primary btn-sm" id="add_data">Add More Test</button>  <br/><br />        -->
<form id="createForm">

<input type="hidden" class="form-control" id="num" name="num" readonly>
<input type="hidden" class="form-control" name="patient_id[]" id="patient_id" value="<?php echo $patient_id;?>" readonly>
<input type="hidden" class="form-control" id="invoice_no" name="invoice_no" required>

<div class="col-sm-12">
    <div class="form-group">
    <label for="report_date">Reporting Date</label>
    <input type="date" class="form-control" id="report_date" name="report_date[]" required>
  </div>
</div>

  <div class="form-row">
    <div class="form-group col-sm-6">
      <label for="test_id">Test Name</label>
	    <select class="form-control" name="test_id[]" id="test_id" required>
                  <!-- <option value="">Select Test</option>
                         <?php 
                         foreach($all_tests as $user){
	                     echo "<option value='".$user['test_id']."' >".$user['test_name']."</option>";
                         } ?> --> 

                        <?php foreach ($all_tests as $user) { ?>
                        <option value="<?php echo $user["test_id"]; ?>"><?php echo $user["test_name"]; ?></option>   
                         <?php } ?>

														
                </select>  
    </div>
    <div class="form-group col-sm-6">
    <label for="file">Test Report</label>
    <input type="file" class="form-control"  id="file">
    </div>
  </div>

  <div class="form-row">
    <div class="form-group col-sm-6">
      <label class="custom-file" for="code">Test Code</label>
      <span class="form-control" id="code" name="code[]" readonly></span>
    </div>
    <div class="form-group col-sm-6">
      <label for="doctor">Referal Doctor</label>
      <span class="form-control" id="doctor" name="doctor[]" readonly></span>
    </div>
  </div>

  <div class="form-row">
    <div class="form-group col-sm-6">
      <label for="description">Description</label>
      <input type="text" class="form-control" id="description" name="description[]" value="Health Issue" required />
    </div>
    <div class="form-group col-sm-6">
      <label>Standard Charge</label>
      <span class="form-control" id="standard_charge" name="standard_charge[]" readonly></span>
    </div>
  </div>

  <div class="form-row">
  <div class="form-group col-sm-6 required">
      <label for="applied_charge">Applied Charge</label>
      <input type="number" class="form-control" id="applied_charge" onchange="calculateAmount(this.value)" name="applied_charge[]" required />
 </div>
    <div class="form-group col-sm-6">
      <label for="gst">GST</label>
      <input type="number" class="form-control" id="gst" name="gst[]" value="18" required />
    </div>
  </div>

  <div class="col-sm-12">
    <div class="form-group">
    <label for="total_amount">Grand Total</label>
    <input type="text" class="form-control" id="total_amount" name="total_amount[]" readonly />
  </div>
</div>

         <!-- <button type="submit" class="btn btn-success btn-sm">Save</button> -->
         <button class="btn btn-primary btn-sm" id="add_data">Add More Test</button>     
         <a class = "btn btn-success btn-sm" href="<?php echo base_url()."patient/pdf"?>">Print</a>
         <a class = "btn btn-primary btn-sm" href="<?php echo base_url()."patient"?>">Back</a>
       </form>
      </div>
    </div>
  </div><br /><br />
  <table class="table table-bordered table-hover" name="logic" id="logic">
  <thead class="indigo white-text">
          <tr>
          <th class="text-center">No</th>
            <!-- <th class="text-center">Invoice No</th> -->
            <th class="text-center">P Id</th>
            <th class="text-center">Test Id</th>
            <th class="text-center">Code</th>
            <th class="text-center">Description</th>
            <th class="text-center">Doctor</th>
            <th class="text-center">Date</th>
            <th class="text-center">Std.Charge</th>
            <th class="text-center">App.Charge</th>
            <th class="text-center">GST</th>
            <th class="text-center">Total</th>
          </tr>
        </thead>
        <tbody>
          <tr>
          </tr>
        </tbody>
  </table>
  <input type="submit" class="btn btn-success btn-sm" value="Save" id="save">
  <input type="submit" class="btn btn-success btn-sm" value="Save & Print" id="print">
</div>

</body>
<script src="//code.jquery.com/jquery-1.12.4.js"></script>
<script src="<?php echo base_url('assets/jquery/sweetalert-dev.js')?>"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
<script type="text/javascript" src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
<link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/sweetalert2@7.12.15/dist/sweetalert2.min.css'>
<script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.33.1/sweetalert2.min.js"></script>
    

<script type="text/javascript">
   function calculateAmount(val) {
                var gst =  document.getElementById('gst').value;
                var price = val;
                var tot_price = +price + (+price * +gst/100);
                document.getElementById('total_amount').value = tot_price;
                // return total_amount;
                // $('#total_amount').val((tot_price).toFixed(2));
            }

$(function(){
    var set_number = function(){
    var table_len = $('#logic tbody tr').length+0;
    $('#num').val(table_len);
   }
   set_number();

   $('#add_data').click(function(){
       var no               = $('#num').val();
      //  var no1               = $('#invoice_no').val();
       var patient_id       = $('#patient_id').val();
       var test_name        = $('#test_id').val();
       var code             = $('#code').html();
       var description      = $('#description').val();
       var referal_doctor   = $('#doctor').html();
       var report_date      = $('#report_date').val();
       var standard_charge  = $('#standard_charge').html();
       var applied_charge   = $('#applied_charge').val();
       var gst              = $('#gst').val();
       var total_amount     = $('#total_amount').val();
       $('#logic tbody:last-child').append(
         '<tr>'+
           '<td align="center">'+no+'</td>'+
          //  '<td align="center">'+no1+'</td>'+
           '<td align="center">'+patient_id+'</td>'+
           '<td align="center">'+test_name+'</td>'+
           '<td align="center">'+code+'</td>'+
           '<td align="center">'+description+'</td>'+
           '<td align="center">'+referal_doctor+'</td>'+
           '<td align="center">'+report_date+'</td>'+
           '<td align="center">'+standard_charge+'</td>'+
           '<td align="center">'+applied_charge+'</td>'+
           '<td align="center">'+gst+'</td>'+
           '<td align="center">'+total_amount+'</td>'+
         '</tr>'
       );
       $('#num').val('');
       $('#invoice_no').val('');
      //  $('#patient_id').val('');  
       $('#test_id').val('');
       $('#code').html('');
      //  $('#description').val('');
       $('#doctor').html('');
       $('#report_date').val('');
       $('#standard_charge').html('');
       $('#applied_charge').val('');
      //  $('#gst').val('');
       $('#total_amount').val('');

       set_number();

   });

   $('#save').click(function(){
     var table_data = [];

     $('#logic tr').each(function(row,tr){
       if($(tr).find('td:eq(0)').text() == ""){

       }else{
        var sub = {
         'num'             : $(tr).find('td:eq(0)').text(),
        //  'invoice_no'      : $(tr).find('td:eq(1)').text(),
         'patient_id'      : $(tr).find('td:eq(1)').text(),
         'test_id'         : $(tr).find('td:eq(2)').text(),
         'code'            : $(tr).find('td:eq(3)').text(),
         'description'     : $(tr).find('td:eq(4)').text(),
         'doctor'          : $(tr).find('td:eq(5)').text(),
         'report_date'     : $(tr).find('td:eq(6)').text(),
         'standard_charge' : $(tr).find('td:eq(7)').text(),
         'applied_charge'  : $(tr).find('td:eq(8)').text(),
         'gst'             : $(tr).find('td:eq(9)').text(),
         'total_amount'    : $(tr).find('td:eq(10)').text(),
       };
       table_data.push(sub);

       }
      
     });

    //  console.log(table_data);


  var data = { "logic" : table_data };
  $.ajax({
            url: '<?=base_url()?>patient/save',
            data: data,
            type: "post",
            async: false,
            dataType: 'json',
            success: function(result){
              if(result.status == "success") {
          swal('Successfully Saved.','','success');
        }else{
          swal('Error Saving.','','Warning');
        }
         
        // $('#logic')[0].reset();
        // alert("Successfully inserted");
        //       },
        //    error: function()
        //    {
        //     alert("error");
        //    }
          
       }
  });
  
  });
});   


$(document).ready(function(){
 $('#test_id').change(function(){
  var test_id = $(this).val();
  $.ajax({
   url:'<?=base_url()?>patient/userDetails',
   method: 'post',
   data: {test_id: test_id},
   dataType: 'json',
   success: function(response){
     var len = response.length;
     $('#code,#standard_charge,#doctor').text('');
     if(len > 0){
       // Read values
       var num = response[0].code;
       var charge = response[0].standard_charge;
       var doctor = response[0].doctor;

       $('#code').text(num);
       $('#standard_charge').text(charge);
       $('#doctor').text(doctor);

     }

   }
 });
});
});


$("#createForm").submit(function(event) {
  event.preventDefault();
  $.ajax({
            url: '<?=base_url()?>patient/insert',
            data: $("#createForm").serialize(),
            type: "post",
            async: false,
            dataType: 'json',
            success: function(response){
              
                $('#createForm')[0].reset();
                alert('Successfully inserted');
              },
           error: function()
           {
            alert("error");
           }
      });
});

</script>
</html>	

