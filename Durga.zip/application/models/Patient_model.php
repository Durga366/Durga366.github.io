<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Patient_model extends CI_Model 
{
	
	  function __construct(){
		parent::__construct();
	}
  function getAllPatients(){
		$this->db->select('*');
		$qry = $this->db->get('patient');
		$rs = $qry->result_array();		
		return $rs;
	}
	
	function getPatientByID($patient_id){
		$this->db->select('*');
		$this->db->like('patient_id', $patient_id);
		$qry = $this->db->get('patient');
		$rs = $qry->result_array();
		return $rs[0];
  }

  function getUsernames(){
    $this->db->select('*');
    $records = $this->db->get('test');
    $tests = $records->result_array();
    return $tests;
  }
  function getTestDetails($postData=array()){
    $response = array();    
    if(isset($postData['test_id']) ){
    $this->db->select('*');
    $this->db->where('test_id', $postData['test_id']);
    $records = $this->db->get('test');
    $response = $records->result_array();    
  }     
    return $response;
  }

  function save($test_list){
  $last_invoice_id = $this->last_invoice_id();
  // echo $last_invoice_id;
    for($x = 0; $x< count($test_list); $x++){
      $data[] = array(
        'invoice_no'      => (int)$last_invoice_id+1,
        'patient_id'      => $test_list[$x]['patient_id'],
        'test_id'         => $test_list[$x]['test_id'],
        'description'     => $test_list[$x]['description'],
        'report_date'     => $test_list[$x]['report_date'],
        'applied_charge'  => $test_list[$x]['applied_charge'],
        'gst'             => $test_list[$x]['gst'],
        'total_amount'    => $test_list[$x]['total_amount'],
      );
    }
    try {
       for($x = 0; $x< count($test_list); $x++){
        $this->db->insert('patient_test_details',$data[$x]);
       }
      return 'success';
    }catch(Exception $e){
      return 'failed';
    }

  }

  // public function insertDetails($data){
	// 	$query = $this->db->insert('details',$data);
	// 	return $query;
  // }

  public function last_invoice_id(){
    $sql = "SELECT MAX(invoice_no) as invoiceno FROM patient_test_details";
    $query = $this->db->query($sql);
    //$result = $query->result();  //  returns the query result as an array of objects
    $result = $query->row(); // returns a single result row
    $invoice =$result->invoiceno;
    return $invoice;
  }

//   function getallProductsBasedOnCategory($catId){
//     $this->db->where('category_id', $catId);
//     $this->db->where('product_status','1');
//     $query = $this->db->get('product');
//     return $query->result();
// }

  function getallDB(){
    $this->db->select('*');
    $this->db->from('patient_test_details');
    $this->db->order_by('invoice_no', 'ASC');
    $this->db->join('patient','patient.patient_id = patient_test_details.patient_id');
    $this->db->join('test','test.test_id=patient_test_details.test_id');
    $query=$this->db->get();
    return $query->result();
}

  function fetch(){
    $this->db->order_by('id', 'ASC');
    return $this->db->get('patient_test_details');
  }
  function fetch1(){
    $this->db->order_by('patient_id', 'ASC');
    return $this->db->get('patient');
  }
  function fetch2(){
    $this->db->order_by('test_id', 'ASC');
    return $this->db->get('test');
  }
  function fetch_single_details($id){
    $this->db->where('id', $id);
    $data = $this->db->get('patient_test_details');
    // $output = '<table width="100%" cellspacing="5" cellpadding="5">';
    // foreach($data->result() as $row)
    // {
    //  $output .= '
    //  <tr>
    //   <td width="100%">
    //    <p><b>Invoice no : </b>'.$row->invoice_no.'</p>
    //    <p><b>Patient Id : </b>'.$row->patient_id.'</p>
    //    <p><b>Test Id : </b>'.$row->test_id.'</p>
    //    <p><b>Description : </b>'.$row->description.'</p>
    //    <p><b>Date : </b>'.$row->report_date.'</p>
    //    <p><b>Charge : </b>'.$row->applied_charge.'</p>
    //    <p><b>GST : </b>'.$row->gst.'</p>
    //    <p><b>Total : </b> '.$row->total_amount.' </p>
    //   </td>
    //  </tr>
    //  ';
    // }
   
    // $output .= '</table>';
    // return $output;
    return $data->result;
   }

   function fetch_single_details1($patient_id){
    $this->db->where('patient_id', $patient_id);
    $data = $this->db->get('patient');
    // $output = '<table width="100%" cellspacing="5" cellpadding="5">';
    // foreach($data->result() as $row)
    // {
    //  $output .= '
    //  <tr>
    //   <td width="50%">
    //    <p><b>Patient Id : </b>'.$row->patient_id.'</p>
    //    <p><b>Name : </b>'.$row->name.'</p>
    //    <p><b>Email : </b>'.$row->email.'</p>
    //    <p><b>Age : </b>'.$row->age.'</p>
    //    <p><b>Phone : </b>'.$row->mobile.'</p>
    //   </td>
    //  </tr>
    //  ';
    // }
   
    // $output .= '</table>';
    // return $output;
    return $data->result;

   }

   function fetch_single_details2($test_id){
    $this->db->where('test_id', $test_id);
    $data = $this->db->get('test');
    // $output = '<table width="100%" cellspacing="5" cellpadding="5">';
    // foreach($data->result() as $row)
    // {
    //  $output .= '
    //  <tr>
    //   <td width="50%">
    //    <p><b>Test Id : </b>'.$row->test_id.'</p>
    //    <p><b>Test Name : </b>'.$row->test_name.'</p>
    //    <p><b>Code : </b>'.$row->code.'</p>
    //    <p><b>Std.Charge : </b>'.$row->standard_charge.'</p>
    //    <p><b>Doctor : </b>'.$row->doctor.'</p>
    //   </td>
    //  </tr>
    //  ';
    // }
   
    // $output .= '</table>';
    // return $output;
    return $data->result;
   }
  
   function get_search() {
    $match = $this->input->post('search');
    $this->db->like('invoice_no',$match);
    $this->db->or_like('test_id',$match);
    $this->db->or_like('applied_charge',$match);
    return $this->db->get('patient_test_details');
  }

}
    
