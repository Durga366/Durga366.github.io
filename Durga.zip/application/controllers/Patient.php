<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Patient extends CI_Controller
{	
	function __construct(){
		parent::__construct();
        $this->load->model('patient_model');
        $this->load->library('form_validation');
        $this->load->library('pdf');
	}
		
	function index(){
        $data['getPatients'] = $this->patient_model->getAllPatients();	     
        $this->load->view('patient_view', $data);
	}

	function view($id){
        $getPatientID = $id;
        $tests = $this->patient_model->getUsernames();
        $data['all_tests'] = $tests;
	    $data['records'] = $this->patient_model->getPatientByID($getPatientID);
	    $this->load->view('details', $data);		
        }
        public function userDetails(){
        $postData = $this->input->post();
        $data = $this->patient_model->getTestDetails($postData);   
        echo json_encode($data);
        }

        function save(){

        $max_invoice_no =  $this->patient_model->last_invoice_id();
        // print_r($max_invoice_no);
        // print_r((int)$max_invoice_no);   
        // $invoice_no   = intval($max_invoice_no)+1;
        // echo $max_invoice_no;

        $test_list = $this->input->post('logic');        
        $status = $this->patient_model->save($test_list);
        $this->output->set_content_type('application/json');
	echo json_encode(array('status' => $status));
        }

        // public function insert()
	//{
        //  $max_invoice_no =  $this->patient_model->last_invoice_id();
        //  print_r($max_invoice_no);
        //  print_r((int)$max_invoice_no);   
        //      echo $max_invoice_no;
        // $invoice_no   = intval($max_invoice_no)+1;
        // $patient_id  = $this->input->post('patient_id');
        // $report_date = $this->input->post('report_date');
        // $test_name   = $this->input->post('test_id');
        // $description = $this->input->post('description');
        // // $std_charge  = $this->input->post('std_charge');
        // $applied_charge      = $this->input->post('applied_charge');
        // // $sum         = $this->input->post('sum');
        // $gst         = $this->input->post('gst');
        // $total_amount= $this->input->post('total_amount');

	// 	$data = array(
        // //  'invoice_no'     => $invoice_no,       
        //     'patient_id'     => $patient_id,
        //     'report_date'    => $report_date,
        //     'test_id'        => $test_name,
        //     'description'    => $description,
        // //  'std_charge'     => $std_charge,
        //     'applied_charge' => $applied_charge,
        // //  'sum'            => $sum,
        //     'gst'            => $gst,
        //     'total_amount'   => $total_amount
          
	// 	);
	// 	$this->load->model('patient_model');
	// 	$insert = $this->patient_model->insertDetails($data);
	// 	echo json_encode($insert);
        // }

        function show(){
                $data['alldb'] = $this->patient_model->getallDB();
                $this->load->view('data',$data);       
        }
        
        function pdf(){
                $data['patient_data'] = $this->patient_model->fetch();
                $data['p_data'] = $this->patient_model->fetch1();	
                $data['t_data'] = $this->patient_model->fetch2();     
                $this->load->view('printpdf', $data);       
        } 

        // function getPatientTest(){
        //         $patient_id = $this->uri->segment(3);
        //         $data['patienttData']=$this->product_model->getParentCategory($patient_id) ;    
        //         $data['patient']=[];
        //         foreach ($data['patienttData'] as $element) { 
        //             $data['test']=$this->product_model->getallProductsBasedOnCategory($element->categoryid) ;                   
        //             $data['patient'] = array_merge( $data['test'], $data['patient']);
        //         }
        //         // var_dump($data['products']);
        //         $this->load->view('clienttend/Category', $data);
        //       }


        function pdfdetails()
        {
        if($this->uri->segment(3)){
        $id = $this->uri->segment(3);
        // $data['alldb'] = $this->patient_model->getallDB();
        // $this->load->view('data',$data);               
        $html_content = '<h3 align="center">Patient Test Reports</h3>';
        $html_content .= $this->patient_model->fetch_single_details($id);
        $html_content .= $this->patient_model->fetch_single_details1($id);
        $html_content .= $this->patient_model->fetch_single_details2($id);
        $this->pdf->loadHtml($html_content);
        $this->pdf->render();
        $this->pdf->stream("".$id.".pdf", array("Attachment"=>0)); 
        
           }
        $output = '<table width="100%" cellspacing="5" cellpadding="5">';
    foreach($data->result() as $row)
    {
      
     $output .= '
     <tr>
      <td width="100%">
       <p><b>Invoice no  : </b>'.$row->invoice_no.'</p>
       <p><b>Patient Id  : </b>'.$row->patient_id.'</p>
       <p><b>Name        : </b>'.$row->name.'</p>
       <p><b>Email       : </b>'.$row->email.'</p>
       <p><b>Age         : </b>'.$row->age.'</p>
       <p><b>Phone       : </b>'.$row->mobile.'</p>
       <p><b>Test Id     : </b>'.$row->test_id.'</p>
       <p><b>Test Name   : </b>'.$row->test_name.'</p>
       <p><b>Code        : </b>'.$row->code.'</p>
       <p><b>Std.Charge  : </b>'.$row->standard_charge.'</p>
       <p><b>Doctor      : </b>'.$row->doctor.'</p>
       <p><b>Description : </b>'.$row->description.'</p>
       <p><b>Date        : </b>'.$row->report_date.'</p>
       <p><b>Charge      : </b>'.$row->applied_charge.'</p>
       <p><b>GST         : </b>'.$row->gst.'</p>
       <p><b>Total       : </b> '.$row->total_amount.' </p>
      </td>
     </tr>
     ';
    }
   
    $output .= '</table>';
    return $output;
        
        }
     
        function search(){
        $data['patient_data'] = $this->patient_model->get_search();
        $this->load->view('printpdf', $data);
        }   
       
}